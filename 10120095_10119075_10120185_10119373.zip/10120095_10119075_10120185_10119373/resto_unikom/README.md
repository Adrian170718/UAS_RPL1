# PHP_Kasir-Restoran
Membuat Aplikasi Kasir Restoran Berbasis Web Menggunakan PHP MySQL

http://localhost/resto_unikom/resto1/ (tampilan Awal Web resto_unikom)

http://localhost/resto_unikom/resto_unikom/login.php (tampilan login dan halaman admin)

Akun Admin

Pass: admin | Username: admin

